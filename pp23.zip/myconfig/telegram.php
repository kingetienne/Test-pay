<?php
	$botToken=""; // telegram bot api
	$IdTelegram=array(""); // telegram id
	$botToken_logs=""; // log telegram log (to be clear make another bot and named logs)
	$IdTelegram_logs=array(""); // log telegram id (and here put ur chat ID or group ID as u like to receive logs on it)
?>
  