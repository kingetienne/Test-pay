<?php
/*
Scama page by Nayfer
You want your private scama page ?
contact me on telegram @nayfercrax
*/
	exit(header("Location: ../index.php"));
?>
